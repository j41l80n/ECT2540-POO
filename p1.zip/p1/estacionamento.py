import patio

class Estacionamento:
	def __init__(self, patio=5):
		self.__patio = patio
		total_carros = 0

	def get_quantidade_carros(self):
		return total_carros