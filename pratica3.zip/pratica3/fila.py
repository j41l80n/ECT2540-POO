import lista_encadeada

class Fila():
	def __init__(self):
		self.__contador = 0
		
	def enfileira(self):
		pass

	def desenfileira(self):
		pass

	def eh_vazia(self):
		# return True
		pass

	def imprime(self):
		print('teste') 