import tkinter as tk

root = tk.Tk() # janela principal de um programa
root.title('Programa em TK')

root.mainloop() # repassa o controle para a interface gráfica